﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите n_min: ");
        int n_min = Convert.ToInt32(Console.ReadLine());

        Console.Write("Введите n_max: ");
        int n_max = Convert.ToInt32(Console.ReadLine());

        long product = CalculateProduct(n_min, n_max);

        if (product == 1)
        {
            Console.WriteLine("В заданном интервале нет четных чисел, делящихся на 4.");
        }
        else
        {
            Console.WriteLine($"Произведение четных чисел, делящихся на 4 в интервале [{n_min}, {n_max}]: {product}");
        }
    }

    static long CalculateProduct(int min, int max)
    {
        long product = 1; 
        bool hasEvenDivisibleBy4 = false; 

        for (int i = min; i <= max; i++)
        {
            if (i % 2 == 0 && i % 4 == 0)
            {
                product *= i; 
                hasEvenDivisibleBy4 = true; 
            }
        }

        return hasEvenDivisibleBy4 ? product : 1;
    }
}
