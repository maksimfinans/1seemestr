﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите n_min: ");
        int n_min = Convert.ToInt32(Console.ReadLine());

        Console.Write("Введите n_max: ");
        int n_max = Convert.ToInt32(Console.ReadLine());

        long productFor = CalculateProductFor(n_min, n_max);
        Console.WriteLine($"Произведение нечетных чисел (for): {productFor}");

        long productWhile = CalculateProductWhile(n_min, n_max);
        Console.WriteLine($"Произведение нечетных чисел (while): {productWhile}");

        long productDoWhile = CalculateProductDoWhile(n_min, n_max);
        Console.WriteLine($"Произведение нечетных чисел (do-while): {productDoWhile}");
    }

    static long CalculateProductFor(int min, int max)
    {
        long product = 1;
        bool hasOddNumbers = false;

        for (int i = min; i <= max; i++)
        {
            if (i % 2 != 0) 
            {
                product *= i;
                hasOddNumbers = true;
            }
        }

        return hasOddNumbers ? product : 0; 
    }

    static long CalculateProductWhile(int min, int max)
    {
        long product = 1;
        bool hasOddNumbers = false;
        int i = min;

        while (i <= max)
        {
            if (i % 2 != 0)
            {
                product *= i;
                hasOddNumbers = true;
            }
            i++;
        }

        return hasOddNumbers ? product : 0; 
    }

    static long CalculateProductDoWhile(int min, int max)
    {
        long product = 1;
        bool hasOddNumbers = false;
        int i = min;

        do
        {
            if (i % 2 != 0)
            {
                product *= i;
                hasOddNumbers = true;
            }
            i++;
        } while (i <= max);

        return hasOddNumbers ? product : 0; 
    }
}

