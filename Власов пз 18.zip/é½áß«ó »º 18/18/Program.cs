﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите значение A: ");
        double A = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите значение C: ");
        double C = Convert.ToDouble(Console.ReadLine());

        int width = 40;     
        int height = 20;   
        double xMin = -10;  
        double xMax = 10;   

        double[] yValues = new double[width];

        for (int i = 0; i < width; i++)
        {
            double x = xMin + (xMax - xMin) * i / (width - 1); 
            yValues[i] = A * x * x + C; 
        }

        double yMin = double.MaxValue;
        double yMax = double.MinValue;

        for (int i = 0; i < width; i++)
        {
            if (yValues[i] < yMin) yMin = yValues[i]; 
            if (yValues[i] > yMax) yMax = yValues[i]; 
        }

        for (int h = height; h >= 0; h--)
        {
            double yLevel = yMin + (yMax - yMin) * h / height; 
            for (int i = 0; i < width; i++)
            {
                if (Math.Abs(yValues[i] - yLevel) < (yMax - yMin) / (height * 2)) 
                {
                    Console.Write("*");
                }
                else if (i == width / 2 && h == height / 2) 
                {
                    Console.Write("+");
                }
                else
                {
                    Console.Write(" ");
                }
            }
            Console.WriteLine();
        }

        
        for (int i = 0; i < width; i++)
        {
            if (i == width / 2) 
            {
                Console.WriteLine("^");
            }
            else 
            {
                Console.WriteLine("-");
            }
        }
        Console.WriteLine($"A: {A}, C: {C} - график функции y = {A}x^2 + {C}");
    }
}
