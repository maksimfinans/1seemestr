﻿using System;

class Program
{
    static void Main()
    {
        
        Console.Write("Введите требуемую точность: ");
        double precision = Convert.ToDouble(Console.ReadLine());

        double sum = 44.0 / 3.0; 
        double previousSum;
        double term; 
        int k = 0; 

        do
        {
            previousSum = sum; 
            term = (k % 2 == 0 ? 1 : -1) * (4.0 / (2.0 * k + 5.0)); 
            sum += term; 
            k++; 
        } while (Math.Abs(sum - previousSum) > precision); 

        Console.WriteLine($"Количество членов ряда: {k}");
        Console.WriteLine($"Сумма ряда: {sum}");
    }
}
