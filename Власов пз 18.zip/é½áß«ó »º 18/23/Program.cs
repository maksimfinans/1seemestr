﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.Write("Введите количество разрядов (единиц): ");
        if (!int.TryParse(Console.ReadLine(), out int onesCount) || onesCount < 0 || onesCount > 64)
        {
            Console.WriteLine("Некорректный ввод. Пожалуйста, введите число от 0 до 64.");
            return;
        }

        List<ulong> numbers = GenerateNumbers(onesCount);

        Console.WriteLine($"Все возможные значения с {onesCount} единицами в двоичном представлении:");
        foreach (var number in numbers)
        {
            Console.WriteLine(number);
        }
    }

    static List<ulong> GenerateNumbers(int onesCount)
    {
        List<ulong> result = new List<ulong>();
        ulong maxNumber = (1UL << 64) - 1;

        for (ulong i = 0; i <= maxNumber; i++)
        {
            if (CountSetBits(i) == onesCount)
            {
                result.Add(i);
            }
        }

        return result;
    }

    static int CountSetBits(ulong number)
    {
        int count = 0;
        while (number > 0)
        {
            count += (int)(number & 1);
            number >>= 1; 
        }
        return count;
    }
}

