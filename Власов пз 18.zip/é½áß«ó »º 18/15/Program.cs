﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите радиус окружности: ");
        double radius = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите желаемую точность: ");
        double targetAccuracy = Convert.ToDouble(Console.ReadLine());

        int totalPoints = 0;
        int pointsInCircle = 0;
        double pi = Math.PI;
        double calculatedArea = 0.0;
        double previousArea = 0.0;

        Random random = new Random();

        do
        {
            double x = random.NextDouble() * (2 * radius) - radius; 
            double y = random.NextDouble() * (2 * radius) - radius; 

            if (x * x + y * y <= radius * radius)
            {
                pointsInCircle++;
            }
            totalPoints++;

            calculatedArea = (double)pointsInCircle / totalPoints * (4 * radius * radius);

        } while (Math.Abs(calculatedArea - previousArea) > targetAccuracy);

        Console.WriteLine($"Приближенная площадь окружности: {calculatedArea}");
        Console.WriteLine($"Фактическая площадь окружности: {pi * radius * radius}");
    }
}

