﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.Write("Введите количество цифр числа: ");
        int digitCount = int.Parse(Console.ReadLine());

        Console.Write("Введите сумму цифр числа: ");
        int digitSum = int.Parse(Console.ReadLine());

        if (digitCount <= 0 || digitSum < 0)
        {
            Console.WriteLine("Количество цифр должно быть больше 0, а сумма цифр должна быть неотрицательной.");
            return;
        }

        List<int> results = new List<int>();

        int start = (int)Math.Pow(10, digitCount - 1); 
        int end = (int)Math.Pow(10, digitCount) - 1;   

        for (int number = start; number <= end; number++)
        {
            if (GetDigitSum(number) == digitSum)
            {
                results.Add(number);
            }
        }

        if (results.Count > 0)
        {
            Console.WriteLine($"Числа с {digitCount} цифрами и суммой цифр {digitSum}:");
            foreach (int result in results)
            {
                Console.WriteLine(result);
            }
        }
        else
        {
            Console.WriteLine($"Нет чисел с {digitCount} цифрами и суммой цифр {digitSum}.");
        }
    }

    static int GetDigitSum(int number)
    {
        int sum = 0;
        while (number > 0)
        {
            sum += number % 10; 
            number /= 10;       
        }
        return sum;
    }
}
