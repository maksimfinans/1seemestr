﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.Write("Введите целое положительное число: ");
        if (!int.TryParse(Console.ReadLine(), out int number) || number <= 0)
        {
            Console.WriteLine("Некорректный ввод. Пожалуйста, введите положительное целое число.");
            return;
        }

        List<int> divisors = FindDivisors(number);

        Console.WriteLine($"Делители числа {number}: {string.Join(", ", divisors)}");
    }

    static List<int> FindDivisors(int number)
    {
        List<int> divisors = new List<int>();

        for (int i = 1; i <= number; i++)
        {
            if (number % i == 0)
            {
                divisors.Add(i);
            }
        }

        return divisors;
    }
}
