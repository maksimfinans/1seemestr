﻿using System;

class Program
{
    static void Main()
    {
        double start = 0; 
        double end = Math.PI;  
        double step = 0.01; 

        double area = 0.0; 

        for (double x = start; x < end; x += step)
        {
            double y1 = 7 * Math.Sin(x);
            double y2 = 7 * Math.Sin(x + step);

            area += (y1 + y2) * step / 2;
        }

        Console.WriteLine($"Площадь под кривой y = 7 * sin(x) на интервале [{start}, {end}] составляет: {area}");
    }
}
