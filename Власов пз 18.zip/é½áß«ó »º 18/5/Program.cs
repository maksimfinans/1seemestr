﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите начало интервала (a): ");
        double start = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите конец интервала (b): ");
        double end = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите шаг (h): ");
        double step = Convert.ToDouble(Console.ReadLine());

        if (end <= start)
        {
            Console.WriteLine("Ошибка: конец интервала должен быть больше начала.");
            return; 
        }

        double area = 0.0;

        for (double x = start; x < end; x += step)
        {
            double y1 = Function(x);
            double y2 = Function(x + step);

            area += (y1 + y2) * step / 2;
        }

        Console.WriteLine($"Площадь под кривой y = 2x + 2*sin(x/3) на интервале [{start}, {end}] составляет: {area}");
    }

    static double Function(double x)
    {
        return 2 * x + 2 * Math.Sin(x / 3);
    }
}
