﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите значение A: ");
        double A = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите значение ню (ню): ");
        double nu = Convert.ToDouble(Console.ReadLine());

        double startX = -10; 
        double endX = 10;    
        double step = 0.5;   

        for (double x = startX; x <= endX; x += step)
        {
            double y = A * Math.Sin(nu - x);
            Console.WriteLine($"{x,6:F2} | {y,6:F2} | {GetGraphPosition(y)}");
        }
    }

    static string GetGraphPosition(double y)
    {
        int height = 10; 
        int position = (int)(y + height / 2);

        if (position < 0)
            position = 0;
        else if (position >= height)
            position = height - 1;

        char[] graphLine = new char[height];
        for (int i = 0; i < height; i++)
        {
            graphLine[i] = ' ';
        }

        graphLine[position] = '*';
        return new string(graphLine);
    }
}
