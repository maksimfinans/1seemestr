﻿using System;

class Program
{
    static void Main()
    {
        double start = 0; 
        double end = 10;  
        double step = 0.1; 

        double maxValue = double.MinValue; 
        double correspondingX = start;

        for (double x = start; x <= end; x += step)
        {
            double y = 5 * Math.Cos(3 * x);

            if (y > maxValue)
            {
                maxValue = y;
                correspondingX = x; 
            }
        }

        Console.WriteLine($"Максимальное значение функции: {maxValue}");
        Console.WriteLine($"Соответствующее значение аргумента: {correspondingX}");
    }
}

