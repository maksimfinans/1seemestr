﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace власов22
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.Show(this);

            frm2.label1.Text = textBox2.Text;
            frm2.label2.Text = textBox1.Text;
            frm2.label3.Text = textBox3.Text;

            frm2.label4.Text = dateTimePicker1.Text;
            frm2.label5.Text = comboBox1.Text;

            frm2.label7.Text = textBox4.Text;

            frm2.pictureBox1.Image = (Bitmap)Bitmap.FromFile(openFileDialog_Photo.FileName);

            if (checkBox1.Checked)
            {
                frm2.label6.Visible = true;
            }
            else
            {
                frm2.label6.Visible = false;
            }
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button_AddPhoto_Click(object sender, EventArgs e)
        {
            if (openFileDialog_Photo.ShowDialog() == DialogResult.Cancel)
                return;
        }
    }
}
