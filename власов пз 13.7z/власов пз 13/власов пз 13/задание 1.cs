﻿using System;

class Program
{
    static void Main()
    {
        int[] arr = { 10, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50 };
        foreach (int num in arr)
        {
            if (num > 20 && num < 50)
            {
                Console.Write(num + " ");
            }
        }
    }
}