﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace власов_пз_13
{
    internal class задание_3
    {
            static void Main()
            {
                for (int x = 2; x <= 8; x++)
                {
                    for (int y = 2; y <= 5; y++)
                    {
                        double z = Math.Pow(x, y);
                        Console.WriteLine("x = " + x + ", y = " + y + ", z = " + z);
                    }
                }
            }
    }

}
