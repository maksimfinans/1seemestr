﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace власов_пз_13
{
    internal class задание_2
    {
        static void Main()
        {
            int sum = 0;
            for (int i = 1; i <= 10; i++)
            {
                sum += i * 2 - 1;
            }
            Console.WriteLine("Сумма: " + sum);
        }
    }
}

