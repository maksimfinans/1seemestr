﻿using System;
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите последовательность чисел оканчивающуюся 0:");
        int result = Sum();
        Console.WriteLine("Сумма всех введенных чисел: " + result);
    }
    static int Sum()
    {
        int number = Convert.ToInt32(Console.ReadLine());
        if (number == 0)
        {
            return 0;
        }
        else
        {
            return number + Sum();
        }
    }
}