﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Власов_21
{
    internal class _2_задание
    {
        public class Circle
        {
            private int x;
            private int y;
            private int radius;
            public Circle()
            {
                x = 0;
                y = 0;
                radius = 0;
            }
            public Circle(int radius)
            {
                x = 0;
                y = 0;
                this.radius = radius;
            }
            public Circle(int x, int y)
            {
                this.x = x;
                this.y = y;
                radius = 0;
            }
            public Circle(int x, int y, int radius)
            {
                this.x = x;
                this.y = y;
                this.radius = radius;
            }
            public void DisplayInfo()
            {
                Console.WriteLine($"Circle: Center=({x}, {y}), Radius={radius}");
            }
        }
        class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("Введите координаты центра окружности (x, y) и радиус:");
                Console.Write("x:");
                int x = int.Parse(Console.ReadLine());
                Console.Write("y:");
                int y = int.Parse(Console.ReadLine());
                Console.Write("Радиус:");
                int radius = int.Parse(Console.ReadLine());
                Circle circle1 = new Circle();
                Circle circle2 = new Circle(radius);
                Circle circle3 = new Circle(x, y);
                Circle circle4 = new Circle(x, y, radius);
                Console.WriteLine("\nИнформация об окружностях:");
                circle1.DisplayInfo();
                circle2.DisplayInfo();
                circle3.DisplayInfo();
                circle4.DisplayInfo();
            }
        }
    }
}
